package com.HMRS.controller;


import com.HMRS.model.Employee;
import com.HMRS.repository.EmployeeRepository;
import com.HMRS.service.EmployeeService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;


@Controller

public class EmployeeController {
    private static final Logger log = LoggerFactory.getLogger(EmployeeController.class);


    @Autowired
    private EmployeeService employeeService;
    @Autowired
    private EmployeeRepository employeeRepository;

    @GetMapping("/employeeList")
    public String viewStudentPage(Model model)
    {
        model.addAttribute("listEmployees", employeeService.getAllEmployees());
        return "employee_list";
    }

    @GetMapping("/showNewemployeeForm")
    public String showNewEmployeeForm(Model model)
    {
        //create model attribute to bind form data
        Employee employee = new Employee();
        model.addAttribute("employee", employee);
        return "new_employee";
    }

    @PostMapping("/saveEmployee")
    public String saveEmployee(@ModelAttribute("employee") Employee employee)
    {
        //save student to database
        employeeService.saveEmployee(employee);

        return "redirect:/employeeList";


    }

    @RequestMapping(value = "/get/{sid}")
    public String getEmployeeId(@PathVariable("sid") long sid, Model model)
    {

        Optional<Employee> findEmployeeId = employeeRepository.findById(sid);

        model.addAttribute("student", findEmployeeId);

        log.info("getEmployeeId() : " + sid);
        return "redirect:/employeeList";

    }

    @GetMapping("/showEmployFormForUpdate/{sid}")
    public String showEmployFormForUpdate(@PathVariable(value = "sid") Long sid, Model model)
    {

        Employee employee = employeeService.getEmployeeByID(sid);

        model.addAttribute("employee", employee);
        System.out.print("going to update student html");
        return "update_student";
    }

    @GetMapping("/deleteEmployee/{sid}")
    public String deleteEmployee(@PathVariable(value = "sid") long sid)
    {

        this.employeeService.deleteEmployeeByID(sid);
        return "redirect:/employeeList";
    }

}
