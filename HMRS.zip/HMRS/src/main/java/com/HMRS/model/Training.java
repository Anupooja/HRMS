package com.HMRS.model;

import jakarta.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "classes")
/**
 * this class is for training classes, gets and sets info
 */
public class Training implements Serializable {
    /**
     * id for training classes
     */
    @Id
    private long id;
    /**
     * trainging class name
     */
    @Column(name = "name")
    private String className;
    /**
     * link to access 3rd party training
     */
    @Column(name="linkToTraining")
    private String linkToTraining;

    /**
     * gets training id
     * @return training id
     */
    public long getId() {
        return id;
    }

    /**
     * sets training id
     * @param id
     */

    public void setId(long id) {
        this.id = id;
    }

    /**
     * gets training class name
     * @return class name
     */

    public String getClassName() {
        return className;
    }

    /**
     * sets training class name
     * @param courseName
     */
    public void setClassName(String courseName) {
        this.className = courseName;
    }

    /**
     * gets link to training class
     * @return
     */
    public String getLinkToTraining() {
        return linkToTraining;
    }

    /**
     * sets link for training class
     * @param linkToTraining
     */
    public void setLinkToTraining(String linkToTraining) {
        this.linkToTraining = linkToTraining;
    }




}
