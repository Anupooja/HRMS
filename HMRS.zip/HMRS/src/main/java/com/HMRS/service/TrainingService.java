package com.HMRS.service;

import com.HMRS.model.Training;
import org.springframework.data.domain.Page;
import java.util.List;

public interface TrainingService {
    /**
     * gets list of all training classes
     * @return list of training classes
     */
    List<Training> getAllClasses();

    /**
     * saves training class
     * @param training class
     */
    void saveClass(Training training);

    /**
     * gets training class by id
     * @param id of training
     * @return training class with inputed id
     */
    Training getClassByID(long id);

    /**
     * deletes training class by id
     * @param id of training
     */
    void deleteClassByID(long id);

    Page<Training> findPaginated(int pageNo, int pageSize, String sortField, String sortDir);
}
