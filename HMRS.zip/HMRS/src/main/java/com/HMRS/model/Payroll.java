package com.HMRS.model;

import jakarta.persistence.*;

import java.io.Serializable;
@Entity
@Table(name="Payrolls")
/**
 * this class is for payroll info, getting and setting
 */
public class Payroll implements Serializable {
    /**
     * this is for jobId, which will determine pay rate
     */
    @Id
    @Column(name="job_Id")
    private long jobId;
    /**
     * job title
     */
    @Column(name="title")
    private String title;

    /**
     * gets job id
     * @return jobId
     */

    public long getJobId() {
        return jobId;
    }

    /**
     * sets jobId
     * @param jobId
     */

    public void setJobId(int jobId) {
        this.jobId = jobId;
    }

    /**
     * gets job title
     * @return job title
     */

    public String getTitle() {
        return title;
    }

    /**
     * sets job title
     * @param title
     */

    public void setTitle(String title) {
        this.title = title;
    }

}
