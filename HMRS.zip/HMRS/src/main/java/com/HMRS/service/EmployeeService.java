package com.HMRS.service;
import com.HMRS.model.Employee;
import org.springframework.data.domain.Page;

import java.util.List;

public interface EmployeeService {
    /**
     * gets list of all employees
     * @return list of employees
     */
    List<Employee> getAllEmployees();

    /**
     * saves an employee to database
     * @param employee
     */
    void saveEmployee(Employee employee);

    /**
     * gets and employee by id
     * @param sid
     * @return employee with that sid
     */
    Employee getEmployeeByID(long sid);

    /**
     * deletes an employee by Id
     * @param sid
     */
    void deleteEmployeeByID(long sid);
    Page<Employee> findPaginated(int pageNo, int pageSize, String sortField, String sortDirection);
}
