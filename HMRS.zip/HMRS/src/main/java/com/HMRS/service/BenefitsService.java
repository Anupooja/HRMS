package com.HMRS.service;

public interface BenefitsService {
}
