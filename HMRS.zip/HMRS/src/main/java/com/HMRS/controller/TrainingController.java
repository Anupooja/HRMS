package com.HMRS.controller;

import java.util.List;

import com.HMRS.model.Training;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import com.HMRS.service.TrainingService;

@Controller

public class TrainingController {
    @Autowired
    private TrainingService trainingService;

    //display list of courses
    @GetMapping("/")
    public String viewHomePage(Model model)
    {
        model.addAttribute("listCourses", trainingService.getAllClasses());
        return "index";
    }


    @GetMapping("/showNewCourseForm")
    public String showNewCourseForm(Model model)
    {
        //create model attribute to bind form data
        Training training = new Training();
        model.addAttribute("course", training);
        return "new_course";
    }

    @PostMapping("/saveCourse")
    public String saveCourse(@ModelAttribute("course") Training training)
    {
        //save course to database
        trainingService.saveClass(training);
        return "redirect:/";
        //return "index";
    }

    @GetMapping("/showFormForUpdate/{id}")
    public String showFormForUpdate(@PathVariable(value = "id") long id, Model model)
    {
        //get course from the service
        Training training = trainingService.getClassByID(id);

        //set course as a model attribute to pre=populate the form
        model.addAttribute("course", training);
        return "update_course";
    }

    @GetMapping("/deleteCourse/{id}")
    public String deleteCourse(@PathVariable(value = "id") long id)
    {
        //call course delete method
        this.trainingService.deleteClassByID(id);
        return "redirect:/";
    }

    @GetMapping("/page/{pageNo}")
    public String findPaginated(@PathVariable(value = "pageNo") int pageNo,
                                @RequestParam("sortField") String sortField,
                                @RequestParam("sortDir") String sortDir,
                                Model model)
    {
        int pageSize = 5;

        Page<Training> page = trainingService.findPaginated(pageNo, pageSize, sortField, sortDir);
        List<Training> listCours = page.getContent();

        model.addAttribute("currentPage", pageNo);
        model.addAttribute("totalPages", page.getTotalPages());
        model.addAttribute("totalItems", page.getTotalElements());
        model.addAttribute("sortField", sortField);
        model.addAttribute("sortDir", sortDir);
        model.addAttribute("reverseSortDir", sortDir.equals("asc") ? "desc" : "asc");
        model.addAttribute("listCourses", listCours);
        return "index";
    }

}